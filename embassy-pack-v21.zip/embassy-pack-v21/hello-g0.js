// Standalone demo - import minimal decision logic
const PROFILES = {
  universal: { genes: { MEMO: false, PAR: false, SURGEON: false } }
};

function decide(attributes) {
  const attrSet = new Set(attributes);

  // Gate #0: Check for side effects
  const sideEffects = [];
  if (attrSet.has('oracle:fs')) sideEffects.push('side_effects:fs');
  if (attrSet.has('oracle:net')) sideEffects.push('side_effects:net');
  if (attrSet.has('oracle:env')) sideEffects.push('side_effects:env');

  if (sideEffects.length > 0) {
    return {
      profile: 'universal',
      confidence: 1.0,
      gate: 'G0',
      reasons: sideEffects,
      genes: PROFILES.universal.genes
    };
  }

  return { profile: 'universal', genes: PROFILES.universal.genes };
}

console.log('🛡️ DEMO: Gate #0 blocks side effects\n');

const decision = decide([
  'type:io_bounded',
  'oracle:fs',
  'exec:success',
  'size:m_1_10mb'
]);

console.log('Decision:');
console.log('  Profile:', decision.profile);
console.log('  Gate:', decision.gate);
console.log('  Reasons:', decision.reasons);
console.log('  Result: MEMO=false, PAR=false (safe mode)');
