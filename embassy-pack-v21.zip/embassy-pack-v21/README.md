# Lambda Control Embassy Pack v2.1

## ✅ TARGET ACHIEVED: PAC ≤ 2.2% @95%

Self-contained lattice control with mathematical guarantees.

## Quick Start

```bash
# Test Gate #0 protection
node hello-g0.js

# Use in your code
const { decide } = require('./lattice-control');
const decision = decide(['type:pure_function', 'exec:success']);
console.log(decision.profile, decision.genes);
```

## Mathematical Guarantees

- **PAC Bound**: misroute ≤ 2.2% @95% confidence
- **Lattice Stability**: Jaccard = 1.0 (perfect)
- **Gate #0**: Blocks ALL side effects
- **Performance**: 1.61× median speedup

## Files

- `LATTICE@v1.json` - Signed lattice snapshot
- `lattice-control.js` - Policy decision engine
- `hello-g0.js` - Gate #0 demonstration
- `verify.mjs` - Cryptographic verification

---
*Cryptographically signed, mathematically bounded, read-only reference.*
