#!/bin/bash
echo "🔐 EMBASSY PACK VERIFICATION"
echo "============================"

echo "1. Testing Gate #0..."
if node hello-g0.js | grep -q "universal"; then
  echo "   ✅ Gate #0 blocks side effects"
else
  echo "   ❌ Gate #0 failed"
fi

echo ""
echo "2. Checking files..."
for file in LATTICE@v1.json lattice-control.js hello-g0.js; do
  if [[ -f "$file" ]]; then
    echo "   ✅ $file present ($(wc -c < "$file") bytes)"
  else
    echo "   ❌ $file missing"
  fi
done

echo ""
echo "============================"
echo "Verification complete."
