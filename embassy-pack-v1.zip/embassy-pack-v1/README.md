# Lambda Control Embassy Pack v1

Self-contained lattice control system. No external dependencies.

## Quick Start

```bash
# Test decision engine
node lattice-control.js

# Run conformance tests
node conformance-v1.js

# Verify integrity
node verify.mjs check LATTICE@v1.json
```

## What's Included

- `LATTICE@v1.json` - Immutable lattice snapshot (J=1.0)
- `lattice-control.js` - Decision engine
- `conformance-v1.js` - 40 canonical tests
- `verify.mjs` - Cryptographic verification
- `policies/` - Profiles and thresholds
- `samples/` - Example receipts

## Key Metrics

- **Stability**: Jaccard = 1.0 (perfect)
- **Speedup**: 1.5-3x depending on profile
- **Profiles**: apex, proof, performance, universal
- **Safety**: Gate #0 blocks side effects

## Usage

```javascript
const { decide } = require('./lattice-control');

const decision = decide([
  'type:pure_function',
  'exec:success',
  'oracle:no_fs'
]);

console.log(decision.profile);    // 'apex'
console.log(decision.confidence); // 1.0
console.log(decision.genes);      // {MEMO:true, PAR:true}
```

## Emergency

Set `PL_POLICY=universal` to force safe mode.

---
*This is a read-only reference implementation. Run locally, observe speedup, then decide.*
