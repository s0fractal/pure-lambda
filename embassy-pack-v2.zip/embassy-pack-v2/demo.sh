#!/bin/bash
# Quick demos showing lattice control

echo "🎭 DEMO: Hello Apex (pure function)"
node -e "
const { decide } = require('./lattice-control');
const d = decide(['type:pure_function', 'exec:success', 'oracle:no_fs']);
console.log('Profile:', d.profile);
console.log('Confidence:', d.confidence);
console.log('Genes:', d.genes);
"

echo ""
echo "🎭 DEMO: Hello OOD (unknown attributes)"
node -e "
const { decide } = require('./lattice-control');
const d = decide(['type:validation', 'alien:x', 'alien:y']);
console.log('Profile:', d.profile);
console.log('Confidence:', d.confidence);
console.log('Gate:', d.gate || 'none');
"

echo ""
echo "🎭 DEMO: Gate #0 (side effects)"
node -e "
const { decide } = require('./lattice-control');
const d = decide(['type:io_bounded', 'oracle:fs']);
console.log('Profile:', d.profile);
console.log('Gate:', d.gate);
console.log('Reasons:', d.reasons);
"
