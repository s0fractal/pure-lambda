# Verification Guide

## Quick Verify (1 command)

```bash
node verify.mjs check LATTICE@v1.json lattice-manifest.json
```

Expected output:
```
✅ Verification PASSED
   CID: Qm62651d02daf691423881a9ebe266844d97254c149286
   Signature: Valid
   Timestamp: 2025-09-15T15:26:52.382Z
```

## What's Being Verified

1. **CID Integrity**: SHA256 hash matches the snapshot
2. **Ed25519 Signature**: Cryptographically signed by Lambda Control
3. **Lattice Stability**: J=1.0 (perfect stability)

## Trust Model

- This is a READ-ONLY reference implementation
- Run locally, observe speedup, then decide
- No network calls, no external dependencies
- Emergency: `PL_POLICY=universal` for safe mode

