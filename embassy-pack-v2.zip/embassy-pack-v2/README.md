# Lambda Control Embassy Pack v2

Self-contained lattice control with cryptographic verification.

## Quick Start (2 commands)

```bash
# 1. Verify integrity
node verify.mjs check LATTICE@v1.json

# 2. Run demos
./demo.sh
```

## What's Included

- `LATTICE@v1.json` - Immutable snapshot (J=1.0)
- `lattice-control.js` - Decision engine with Gate #0
- `conformance-v1.js` - 40 canonical tests
- `verify.mjs` - Ed25519 cryptographic verification
- `demo.sh` - Live demonstrations
- `VERIFY.md` - Trust model and verification guide

## Key Guarantees

- **Stability**: Jaccard = 1.0 (mathematically perfect)
- **Safety**: Gate #0 blocks ALL side effects
- **Speedup**: 1.5-3× depending on profile
- **Verification**: Ed25519 signed, CID immutable

## Proof of Impact

```
Median speedup: 1.61×
Energy saved: 61%
Oracle violations: 0
```

## Emergency

```bash
export PL_POLICY=universal  # Instant safe mode
```

---
*This is cryptographically signed reference code. Verify, run locally, observe results.*
