# B2 Embassy Pack

## Complete Stream Algebra in 8 Symbols

```
Atoms = {id, FOCUS, SCAN, DELAY, MERGE, PAIR}
Combinators = {THEN (▶), SPLIT (∆)}
```

## Quick Verification

```bash
# Run golden tests (7 canonical patterns)
node b2-golden.mjs

# Verify B2 compliance
node b2-verify.js example.b2
```

## Properties

✅ **Complete**: Arrow + Choice + Loop
✅ **Minimal**: Just 8 primitives
✅ **Pure**: Gate G0 enforced
✅ **Deterministic**: phash identity

## Key Files

- `B2-SPEC-v1.md` - Canonical specification
- `b2-golden.mjs` - 7 verified patterns
- `b2-verify.js` - Compliance checker
- `operators.md` - RxJS translation table

---
*Finite core. Infinite compositions. Zero ambiguity.*
